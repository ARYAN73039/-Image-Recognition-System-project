import tensorflow as tf
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input, decode_predictions
from tensorflow.keras.preprocessing import image
import numpy as np
import os

class ImageClassifier:
    def __init__(self):
        # Load pre-trained MobileNetV2 model
        self.model = MobileNetV2(weights='imagenet')
        print("Model loaded successfully")
        
    def predict(self, img_path):
        """
        Predict the class of an image using the pre-trained model
        
        Args:
            img_path (str): Path to the image file
            
        Returns:
            list: Top 3 predictions with class name and probability
        """
        try:
            # Load and preprocess the image
            img = image.load_img(img_path, target_size=(224, 224))
            img_array = image.img_to_array(img)
            img_array = np.expand_dims(img_array, axis=0)
            img_array = preprocess_input(img_array)
            
            # Make prediction
            predictions = self.model.predict(img_array)
            
            # Decode and return top 3 predictions
            results = decode_predictions(predictions, top=3)[0]
            
            # Format results as list of dictionaries
            formatted_results = [
                {
                    'class': result[1].replace('_', ' ').title(),
                    'probability': float(result[2]) * 100
                }
                for result in results
            ]
            
            return formatted_results
        except Exception as e:
            print(f"Error in prediction: {str(e)}")
            return []