import os
import sys
import subprocess

def run_app():
    print("Starting Image Recognition System...")
    
    # Get the current directory
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Add the current directory to the path
    sys.path.append(current_dir)
    
    # Create uploads directory if it doesn't exist
    uploads_dir = os.path.join(current_dir, 'app', 'static', 'uploads')
    os.makedirs(uploads_dir, exist_ok=True)
    
    # Import and run the Flask app
    from app.app import app
    print("Server starting at http://localhost:5000")
    app.run(host='0.0.0.0', port=5000, debug=True)

if __name__ == "__main__":
    run_app()