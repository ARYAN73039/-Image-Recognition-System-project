import os
import sys
from app.models.model import ImageClassifier

def test_model():
    """
    Test the image classifier with a sample image.
    You'll need to provide a test image path to run this test.
    """
    # Initialize the model
    print("Initializing model...")
    classifier = ImageClassifier()
    
    # Path to test image - replace with an actual image path
    test_image_path = input("Enter the path to a test image: ")
    
    if not os.path.exists(test_image_path):
        print(f"Error: Image not found at {test_image_path}")
        return
    
    # Make prediction
    print("Making prediction...")
    predictions = classifier.predict(test_image_path)
    
    # Display results
    print("\nPrediction Results:")
    print("-" * 50)
    for i, pred in enumerate(predictions):
        print(f"{i+1}. {pred['class']}: {pred['probability']:.2f}%")
    print("-" * 50)

if __name__ == "__main__":
    test_model()