# Image Recognition System

A web application that allows users to upload images and receive real-time predictions using a pre-trained deep learning model.

## Features

- Image upload and preview
- Real-time image classification
- Display of top 3 predictions with confidence scores
- Responsive web interface

## Technologies Used

- **Backend**: Python, Flask
- **Machine Learning**: TensorFlow, Keras, MobileNetV2 pre-trained model
- **Image Processing**: OpenCV
- **Frontend**: HTML, CSS, JavaScript, Bootstrap

## Project Structure

```
ImageRecognitionSystem/
├── app/
│   ├── models/
│   │   └── model.py         # Image classification model
│   ├── static/
│   │   └── uploads/         # Directory for uploaded images
│   ├── templates/
│   │   └── index.html       # Web interface
│   └── app.py               # Flask application
├── main.py                  # Entry point
└── requirements.txt         # Dependencies
```

## Setup and Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   cd ImageRecognitionSystem
   ```

2. Create a virtual environment:
   ```
   python -m venv venv
   ```

3. Activate the virtual environment:
   - Windows:
     ```
     venv\Scripts\activate
     ```
   - macOS/Linux:
     ```
     source venv/bin/activate
     ```

4. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

5. Run the application:
   ```
   python main.py
   ```

6. Open your browser and navigate to:
   ```
   http://localhost:5000
   ```

## How It Works

1. The application uses a pre-trained MobileNetV2 model from TensorFlow/Keras.
2. When a user uploads an image, it's sent to the server for processing.
3. The image is preprocessed and fed into the model for prediction.
4. The model returns the top 3 most likely classes with confidence scores.
5. Results are displayed to the user in a user-friendly interface.

## Future Improvements

- Add support for custom model training
- Implement object detection capabilities
- Add image enhancement options
- Support for video analysis